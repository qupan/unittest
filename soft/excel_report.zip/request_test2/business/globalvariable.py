#!/usr/bin/env python3
# _*_ coding:utf-8 _*_
'''

__author__:'vaca'
__description__:'设置常量'
__mtime__:2016/6/9
'''


CASE_ID = 1
CASE_NAME = 2
CASE_URL = 3
CASE_METHOD = 4
CASE_HEADERS = 5
CASE_DATA = 6
CASE_CODE = 7