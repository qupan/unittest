from django.apps import AppConfig


class ApimanagerConfig(AppConfig):
    name = 'ApiManager'
