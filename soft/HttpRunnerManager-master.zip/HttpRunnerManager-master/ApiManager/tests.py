# Create your tests here.
import os

import django

from ApiManager.models import ProjectInfo
print(1)