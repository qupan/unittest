# encoding: utf-8

from httprunner.task import HttpRunner
