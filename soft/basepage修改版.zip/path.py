#_*_coding=utf-8_*_
from basePage import *

d=Page("gc","http://www.baidu.com")
d.send_keys(('css','#kw'),'hello')
d.quit()
