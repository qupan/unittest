#coding=utf-8

class Page(object):
    """
    This is a base page class for Page Object.
    """
    def __init__(self, selenium_driver):
        self.dr = selenium_driver



