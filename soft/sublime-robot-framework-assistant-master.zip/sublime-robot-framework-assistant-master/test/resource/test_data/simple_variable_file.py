def get_variables(*args):
    return {'VARIABLE_FILE_1': 123, 'VARIABLE_FILE_2': 987}
