def get_variables(arg1, arg2):
    return {'COMMON_VARIABLE_1': arg1, 'COMMON_VARIABLE_2': arg2}
