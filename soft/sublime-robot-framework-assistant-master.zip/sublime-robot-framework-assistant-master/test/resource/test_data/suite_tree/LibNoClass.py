def library_keyword_1(arg1):
    """library keyword 1 doc"""
    print arg1


def library_keyword_2(arg1, arg2):
    """library keyword 2 doc"""
    print arg1, arg2
