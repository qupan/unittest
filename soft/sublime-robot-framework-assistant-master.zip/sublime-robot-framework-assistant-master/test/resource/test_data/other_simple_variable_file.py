def get_variables(arg):
    return {'VARIABLE_FILE_1': arg, 'VARIABLE_FILE_2': 987}
