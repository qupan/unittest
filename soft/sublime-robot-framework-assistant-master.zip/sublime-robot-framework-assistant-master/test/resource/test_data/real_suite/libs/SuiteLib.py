class SuiteLib(object):

    def __init__(self, arg):
        self.arg = arg

    def sl_kw_1(self):
        pass

    def sl_kw_2(self):
        pass
