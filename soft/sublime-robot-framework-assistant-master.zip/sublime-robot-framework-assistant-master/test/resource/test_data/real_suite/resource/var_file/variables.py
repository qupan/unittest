def get_variables(arg):
    return {'VARIABLE_FROM_FILE': arg}
