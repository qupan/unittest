class MyLibrary():

    def keyword_1(self, arg1):
        """kw 1 doc
        Tags: tag1, tag2
        """
        print arg1

    def keyword_2(self, arg2, arg3):
        """kw 2 doc"""
        return arg2
