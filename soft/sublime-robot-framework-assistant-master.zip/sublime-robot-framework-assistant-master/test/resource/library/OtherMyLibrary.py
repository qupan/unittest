class OtherMyLibrary(object):

    def __init__(self, arg1, arg2):
        self.arg1 = arg1
        self.arg2 = arg2

    def keyword_1(self, arg1):
        """kw 1 doc
        Tags: tag1, tag2
        """
        print arg1

    def keyword_2(self, arg2, arg3):
        """kw 2 doc"""
        return arg2
