"""Modules under the dataparser module are run from the Python where the
Robot Framework is installed. These modules must not be run the from the
Python included in the Sublime Text
"""
